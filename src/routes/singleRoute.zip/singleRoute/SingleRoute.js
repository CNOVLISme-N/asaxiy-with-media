import React from 'react'
import { DATA } from '../../static/index'
import { useParams } from 'react-router-dom'
import './SingleRoute.css'
function SingleRoute() {

    const param = useParams()
    console.log(param);

    const item = DATA.find((item, index) => item.id === param.id)
    console.log(item);

    return (
        <div>
            <div className="container">

                <div className='main_singleRoute'>

                    <div className="singlRoute">
                        <img className='sing_img' src={item.url[0]} alt="" />
                    </div>

                    <div className="singleRout padd_Top">
                        <p>{item.title}</p>
                        <br />
                        <div className="span_text">
                            <span>Sotuvchi:</span>
                            <a href="http://localhost:3000/">uzuzm market</a>
                        </div>

                        <div className="span_text sing_text">
                            <span>Yetkazib berish:</span>
                            <span>1 kun, bepul</span>
                        </div>

                        <br />
                        <br />
                        <span className='miqdor'>Miqdor:</span>
                        <div className="amount">
                            <button className='btn1'>-</button>
                            <button className='btn2'>0</button>
                            <button className='btn3'>+</button>
                            <span className='sotuvda' >sotuvda bor</span>

                        </div>
                        <br />
                        <span>Narx:</span>
                        <div className="item_price">
                            <p>{item.price} so'm</p>
                            <del>530 000 so'm</del>
                        </div>

                        <button className='term_payment'>
                            <mark><h5>Oyiga 120 199 so'mdan</h5></mark>
                            <span>muddatli to'lov</span>
                        </button>

                        <div className="buttons">
                            <button className='btns btns1 '><b>Savatga qoʻshish</b></button>
                            <button className='btns btns2'><b>Tugmani 1 bosishda xarid qilish</b></button>
                        </div>

                    </div>


                </div>

            </div>        </div>
    )
}

export default SingleRoute